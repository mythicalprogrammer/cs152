cat primes.min | parser
