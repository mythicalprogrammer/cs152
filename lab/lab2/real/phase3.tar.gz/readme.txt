cat whateverfile | parser
