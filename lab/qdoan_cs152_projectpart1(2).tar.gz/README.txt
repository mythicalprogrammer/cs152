1. To compile sample.lex

flex sample*.lex
gcc lex.yy.c -lfl

2. To run it

./a.out 

3. To test it

./a.out < test.txt > output.txt

diff output.txt outputkey.txt

Note: You can pipe in whatever file into the a.out to test and pipe out in a txt file to diff test it to check if it is correct.


Note: Thank you for your time ~ Quoc Anh Doan
